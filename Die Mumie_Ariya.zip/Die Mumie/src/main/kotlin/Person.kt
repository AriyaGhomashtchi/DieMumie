open class Person(var name: String,var hp: Int, var zusatzschaden: Int){

}


